package com.msb.es.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.msb.es.entity.CarSerialBrand;

public interface CarSerialBrandServiceMapper extends BaseMapper<CarSerialBrand> {
}
